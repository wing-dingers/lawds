# This is a mod for Rejuvenation LAWDS v13.5.
# The LAWDS team made 99.9% of this code. Give them a cookie.

# Mod: check Hidden Power type and view Pulse3 abilities from summary screen.

# To install this mod: put this file in your LAWDS/Data/Mods folder. 
# If your LAWDS/Data folder doesn't have a Mods folder in it, you can make one first.
# It's okay. No one will be mad.
# Placing this file in that folder should retain it when running the updater.

# This mod adds Hidden Power type checking from the Summary screen.
# This mod also adds the list of Pulse3 abilities to the ability description for each Pulse3 mon.

# You can view a short description of each ability on summary pages where the ability is visible.
# You can do this by pressing the Action button (default: C) on the summary page.
# This view normally shows a longer full description for a single (non-Pulse3) ability.

# Showing Pulse3 abilities and showing Hidden Power types both affect the summary screen.
# It is hard to separate them into 2 different mods because of that, so they are bundled together.

# Enjoy!

class PokemonSummaryScene

  def drawAbilPage(pokemon)
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    @sprites["background"].setBitmap("Graphics/Pictures/Summary/summaryAbility")
    imagepos = []
    if pbPokerus(pokemon) == 1 || pokemon.hp == 0 || !@pokemon.status.nil?
      status = :POKERUS if pbPokerus(pokemon) == 1
      status = @pokemon.status if !@pokemon.status.nil?
      status = :FAINTED if pokemon.hp == 0
      imagepos.push([sprintf("Graphics/Pictures/Party/status%s", status), 120, 100, 0, 0, 44, 16])
    end
    if pokemon.isShiny?
      imagepos.push([sprintf("Graphics/Pictures/shiny"), 2, 134, 0, 0, -1, -1])
    end
    if pbPokerus(pokemon) == 2
      imagepos.push([sprintf("Graphics/Pictures/Summary/statusPKRS"), 176, 100, 0, 0, -1, -1])
    end
    ballused = @pokemon.ballused ? @pokemon.ballused : :POKEBALL
    ballimage = sprintf("Graphics/Pictures/Summary/summaryball" + @pokemon.ballused.to_s)
    imagepos.push([ballimage, 14, 60, 0, 0, -1, -1])
    pbDrawImagePositions(overlay, imagepos)
    pbSetSystemFont(overlay)
    naturename = $cache.natures[@pokemon.nature].name
    itemname = pokemon.hasAnItem? ? getItemName(pokemon.item) : _INTL("None")
    pokename = @pokemon.name
    textpos = [
      [_INTL("ABILITY"), 26, 16, 0, LightBase, LightShadow],
      [pokename, 46, 62, 0, LightBase, LightShadow],
      [pokemon.level.to_s, 46, 92, 0, DarkBase, DarkShadow],
      [_INTL("Item"), 16, 320, 0, LightBase, LightShadow],
      [itemname, 16, 352, 0, DarkBase, DarkShadow],
    ]
    if pokemon.isMale?
      textpos.push([_INTL("♂"), 178, 62, 0, Color.new(24, 112, 216), Color.new(136, 168, 208)])
    elsif pokemon.isFemale?
      textpos.push([_INTL("♀"), 178, 62, 0, ShinyBase, ShinyShadow])
    end
    pbDrawTextPositions(overlay, textpos)
    memo = ""
    if @pokemon.ability.is_a?(PokeAbility)
      abil = $cache.abil[@pokemon.ability.ability]
      abilname = abil.nil? ? (@pokemon.ability.ability.nil? ? NoAbilName : @pokemon.ability.ability.to_s) : abil.name.nil? ? MissingAbilName : getAbilityName(@pokemon.ability.ability)
      abildesc = abil.nil? ? (@pokemon.ability.ability.nil? ? NoAbilDesc : NotRealAbil) : abil.desc.nil? ? MissingAbilDesc : abil.fullDesc
    else
      abil = $cache.abil[@pokemon.ability]
      abilname = abil.nil? ? (@pokemon.ability.nil? ? NoAbilName : @pokemon.ability.to_s) : abil.name.nil? ? MissingAbilName : getAbilityName(@pokemon.ability)
      abildesc = abil.nil? ? (@pokemon.ability.nil? ? NoAbilDesc : NotRealAbil) : abil.desc.nil? ? MissingAbilDesc : abil.fullDesc
    end
    if @pokemon.PULSE3==true
      abilname="Pulse-3"
      # abildesc="It has all of its abilities at once. Use Inspect in a battle to see them."
      abildesc=""
      abilarray = @pokemon.getAbilityList
      abilarray.each do |pulse3_ability|
        pulse_abil = $cache.abil[pulse3_ability]
        pulse_abilname = pulse_abil.nil? ? (pulse3_ability.nil? ? NoAbilName : pulse3_ability.to_s) : pulse_abil.name.nil? ? MissingAbilName : getAbilityName(pulse3_ability)
        pulse_abildesc = pulse_abil.nil? ? (pulse3_ability.nil? ? NoAbilDesc : NotRealAbil) : pulse_abil.desc.nil? ? MissingAbilDesc : pulse_abil.desc
        abildesc+=pulse_abilname
        abildesc+=": "
        abildesc+=pulse_abildesc
        abildesc+=" "
      end
    end
    memo += _INTL("<c3=F8F8F8,686868>Ability:<c3=404040,B0B0B0>\n")
    memo += _INTL("<c3=404040,B0B0B0>{1}\n", abilname)
    memo += _INTL("<c3=F8F8F8,686868>Description:\n")
    memo += _INTL("<c3=404040,B0B0B0>{1}", abildesc)
    drawFormattedTextEx(overlay, 232, 78, 272, memo)
    drawMarkings(overlay, 15, 291, 72, 20, pokemon.markings)
  end

  def drawPageTwo(pokemon)
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    @sprites["background"].setBitmap("Graphics/Pictures/Summary/summary2")
    imagepos = []
    if pbPokerus(pokemon) == 1 || pokemon.hp == 0 || !@pokemon.status.nil?
      status = :POKERUS if pbPokerus(pokemon) == 1
      status = @pokemon.status if !@pokemon.status.nil?
      status = :FAINTED if pokemon.hp == 0
      imagepos.push([sprintf("Graphics/Pictures/Party/status%s", status), 120, 100, 0, 0, 44, 16])
    end
    if pokemon.isShiny?
      imagepos.push([sprintf("Graphics/Pictures/shiny"), 2, 134, 0, 0, -1, -1])
    end
    if pbPokerus(pokemon) == 2
      imagepos.push([sprintf("Graphics/Pictures/Summary/statusPKRS"), 176, 100, 0, 0, -1, -1])
    end
    ballused = @pokemon.ballused ? @pokemon.ballused : :POKEBALL
    ballimage = sprintf("Graphics/Pictures/Summary/summaryball" + @pokemon.ballused.to_s)
    imagepos.push([ballimage, 14, 60, 0, 0, -1, -1])
    pbDrawImagePositions(overlay, imagepos)
    pbSetSystemFont(overlay)
    naturename = $cache.natures[@pokemon.nature].name
    itemname = pokemon.hasAnItem? ? getItemName(pokemon.item) : _INTL("None")
    pokename = @pokemon.name
    textpos = [
      [_INTL("TRAINER MEMO"), 26, 16, 0, LightBase, LightShadow],
      [pokename, 46, 62, 0, LightBase, LightShadow],
      [pokemon.level.to_s, 46, 92, 0, DarkBase, DarkShadow],
      [_INTL("Item"), 16, 320, 0, LightBase, LightShadow],
      [itemname, 16, 352, 0, DarkBase, DarkShadow],
    ]
    if pokemon.isMale?
      textpos.push([_INTL("♂"), 178, 62, 0, Color.new(24, 112, 216), Color.new(136, 168, 208)])
    elsif pokemon.isFemale?
      textpos.push([_INTL("♀"), 178, 62, 0, ShinyBase, ShinyShadow])
    end
    pbDrawTextPositions(overlay, textpos)
    memo = ""
    shownature = (!(pokemon.isShadow? rescue false)) || pokemon.heartStage <= 3
    if shownature
      memo += _INTL("<c3=F83820,E09890>{1}<c3=404040,B0B0B0> nature.\n", naturename)
    end
    if pokemon.timeReceived
      month = pbGetAbbrevMonthName(pokemon.timeReceived.mon)
      date = pokemon.timeReceived.day
      year = pokemon.timeReceived.year
      memo += _INTL("<c3=404040,B0B0B0>{1} {2}, {3}\n", month, date, year)
    end
    mapname = pbGetMapNameFromId(pokemon.obtainMap)
    if (pokemon.obtainText rescue false) && pokemon.obtainText != ""
      mapname = pokemon.obtainText
    end
    if mapname && mapname != ""
      memo += sprintf("<c3=F83820,E09890>%s\n", mapname)
    else
      memo += _INTL("<c3=F83820,E09890>Faraway place\n")
    end
    if pokemon.obtainMode
      mettext = [_INTL("Met at Lv. {1}.", pokemon.obtainLevel),
                 _INTL("Egg received."),
                 _INTL("Traded at Lv. {1}.", pokemon.obtainLevel),
                 "",
                 _INTL("Had a fateful encounter at Lv. {1}.", pokemon.obtainLevel)][pokemon.obtainMode]
      memo += sprintf("<c3=404040,B0B0B0>%s\n", mettext)
      if pokemon.obtainMode == 1 # hatched
        if pokemon.timeEggHatched
          month = pbGetAbbrevMonthName(pokemon.timeEggHatched.mon)
          date = pokemon.timeEggHatched.day
          year = pokemon.timeEggHatched.year
          memo += _INTL("<c3=404040,B0B0B0>{1} {2}, {3}\n", month, date, year)
        end
        mapname = pbGetMapNameFromId(pokemon.hatchedMap)
        if mapname && mapname != ""
          memo += sprintf("<c3=F83820,E09890>%s\n", mapname)
        else
          memo += _INTL("<c3=F83820,E09890>Faraway place\n")
        end
        memo += _INTL("<c3=404040,B0B0B0>Egg hatched.\n")
      else
        memo += "<c3=404040,B0B0B0>\n"
      end
    end
    if shownature
      bestiv = 0
      tiebreaker = pokemon.personalID % 6
      for i in 0...6
        if pokemon.iv[i] == pokemon.iv[bestiv]
          bestiv = i if i >= tiebreaker && bestiv < tiebreaker
        elsif pokemon.iv[i] > pokemon.iv[bestiv]
          bestiv = i
        end
      end
      characteristic = [_INTL("Loves to eat."),
                        _INTL("Often dozes off."),
                        _INTL("Often scatters things."),
                        _INTL("Scatters things often."),
                        _INTL("Likes to relax."),
                        _INTL("Proud of its power."),
                        _INTL("Likes to thrash about."),
                        _INTL("A little quick tempered."),
                        _INTL("Likes to fight."),
                        _INTL("Quick tempered."),
                        _INTL("Sturdy body."),
                        _INTL("Capable of taking hits."),
                        _INTL("Highly persistent."),
                        _INTL("Good endurance."),
                        _INTL("Good perseverance."),
                        _INTL("Likes to run."),
                        _INTL("Alert to sounds."),
                        _INTL("Impetuous and silly."),
                        _INTL("Somewhat of a clown."),
                        _INTL("Quick to flee."),
                        _INTL("Highly curious."),
                        _INTL("Mischievous."),
                        _INTL("Thoroughly cunning."),
                        _INTL("Often lost in thought."),
                        _INTL("Very finicky."),
                        _INTL("Strong willed."),
                        _INTL("Somewhat vain."),
                        _INTL("Strongly defiant."),
                        _INTL("Hates to lose."),
                        _INTL("Somewhat stubborn.")][bestiv * 5 + pokemon.iv[bestiv] % 5]
      memo += sprintf("<c3=404040,B0B0B0>%s\n", characteristic)
      # if $cache.natures[pokemon.nature].like != $cache.natures[pokemon.nature].dislike
      #  memo+=sprintf("<c3=404040,B0B0B0>It likes <c3=F83820,E09890>%s<c3=404040,B0B0B0> food.\n",$cache.natures[pokemon.nature].like)
      #  memo+=sprintf("<c3=404040,B0B0B0>It dislikes <c3=F83820,E09890>%s<c3=404040,B0B0B0> food.\n",$cache.natures[pokemon.nature].dislike)
      # else
      #  memo+=sprintf("<c3=404040,B0B0B0>It does not particularly favor any food.\n")
      # end
    end
    drawFormattedTextEx(overlay, 232, 78, 276, memo)
    drawMarkings(overlay, 15, 291, 72, 20, pokemon.markings)
  end

  def drawPageThree(pokemon)
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    @sprites["background"].setBitmap("Graphics/Pictures/Summary/summary3")
    imagepos = []
    if pbPokerus(pokemon) == 1 || pokemon.hp == 0 || !@pokemon.status.nil?
      status = :POKERUS if pbPokerus(pokemon) == 1
      status = @pokemon.status if !@pokemon.status.nil?
      status = :FAINTED if pokemon.hp == 0
      imagepos.push([sprintf("Graphics/Pictures/Party/status%s", status), 120, 100, 0, 0, 44, 16])
    end
    if pokemon.isShiny?
      imagepos.push([sprintf("Graphics/Pictures/shiny"), 2, 134, 0, 0, -1, -1])
    end
    if pbPokerus(pokemon) == 2
      imagepos.push([sprintf("Graphics/Pictures/Summary/statusPKRS"), 176, 100, 0, 0, -1, -1])
    end
    ballused = @pokemon.ballused ? @pokemon.ballused : :POKEBALL
    ballimage = sprintf("Graphics/Pictures/Summary/summaryball" + @pokemon.ballused.to_s)
    imagepos.push([ballimage, 14, 60, 0, 0, -1, -1])
    pbDrawImagePositions(overlay, imagepos)
    statshadows = []
    for i in 0...6; statshadows[i] = LightShadow; end
    if !(pokemon.isShadow? rescue false) || pokemon.heartStage <= 3
      natup = $cache.natures[pokemon.nature].incStat
      natdn = $cache.natures[pokemon.nature].decStat
      statshadows[natup] = Color.new(136, 96, 72) if natup != natdn
      statshadows[natdn] = Color.new(64, 120, 152) if natup != natdn
    end
    pbSetSystemFont(overlay)
    if pokemon.ability.is_a?(PokeAbility)
    abil = $cache.abil[pokemon.ability.ability]
    abilityname = abil.nil? ? (pokemon.ability.ability.nil? ? NoAbilName : pokemon.ability.ability.to_s) : abil.name.nil? ? MissingAbilName : getAbilityName(pokemon.ability.ability, true)
    abilitydesc = abil.nil? ? (@pokemon.ability.ability.nil? ? NoAbilDesc : NotRealAbil) : abil.desc.nil? ? MissingAbilDesc : abil.desc
    else
      abil = $cache.abil[pokemon.ability]
      abilityname = abil.nil? ? (pokemon.ability.nil? ? NoAbilName : pokemon.ability.to_s) : abil.name.nil? ? MissingAbilName : getAbilityName(pokemon.ability, true)
      abilitydesc = abil.nil? ? (@pokemon.ability.nil? ? NoAbilDesc : NotRealAbil) : abil.desc.nil? ? MissingAbilDesc : abil.desc
    end
    if pokemon.PULSE3==true
      abilityname="Pulse-3"
      # abilitydesc="It has all of its abilities at once."
      abilitydesc=""
      abilarray = pokemon.getAbilityList
      abilarray.each do |pulse3_ability|
        pulse_abil = $cache.abil[pulse3_ability]
        pulse_abilname = pulse_abil.nil? ? (pulse3_ability.nil? ? NoAbilName : pulse3_ability.to_s) : pulse_abil.name.nil? ? MissingAbilName : getAbilityName(pulse3_ability)
        abilitydesc+=pulse_abilname
        abilitydesc+=", "
      end
      abilitydesc = abilitydesc[0..-3]
    end
    itemname = pokemon.hasAnItem? ? getItemName(pokemon.item) : _INTL("None")
    pokename = @pokemon.name
    textpos = [
      [_INTL("SKILLS"), 26, 16, 0, LightBase, LightShadow],
      [pokename, 46, 62, 0, LightBase, LightShadow],
      [pokemon.level.to_s, 46, 92, 0, DarkBase, DarkShadow],
      [_INTL("Item"), 16, 320, 0, LightBase, LightShadow],
      [itemname, 16, 352, 0, DarkBase, DarkShadow],
      [_INTL("HP"), 292, 76, 2, LightBase, LightShadow],
      [sprintf("%3d/%3d", pokemon.hp, pokemon.totalhp), 462, 76, 1, DarkBase, DarkShadow],
      [_INTL("Attack"), 248, 120, 0, LightBase, statshadows[PBStats::ATTACK]],
      [sprintf("%d", pokemon.attack), 456, 120, 1, DarkBase, DarkShadow],
      [_INTL("Defense"), 248, 152, 0, LightBase, statshadows[PBStats::DEFENSE]],
      [sprintf("%d", pokemon.defense), 456, 152, 1, DarkBase, DarkShadow],
      [_INTL("Sp. Atk"), 248, 184, 0, LightBase, statshadows[PBStats::SPATK]],
      [sprintf("%d", pokemon.spatk), 456, 184, 1, DarkBase, DarkShadow],
      [_INTL("Sp. Def"), 248, 216, 0, LightBase, statshadows[PBStats::SPDEF]],
      [sprintf("%d", pokemon.spdef), 456, 216, 1, DarkBase, DarkShadow],
      [_INTL("Speed"), 248, 248, 0, LightBase, statshadows[PBStats::SPEED]],
      [sprintf("%d", pokemon.speed), 456, 248, 1, DarkBase, DarkShadow],
      [_INTL("Ability"), 224, 284, 0, LightBase, LightShadow],
      [abilityname, 362, 284, 0, DarkBase, DarkShadow],
    ]
    if pokemon.isMale?
      textpos.push([_INTL("♂"), 178, 62, 0, Color.new(24, 112, 216), Color.new(136, 168, 208)])
    elsif pokemon.isFemale?
      textpos.push([_INTL("♀"), 178, 62, 0, ShinyBase, ShinyShadow])
    end
    pbDrawTextPositions(overlay, textpos)
    drawTextEx(overlay, 224, 316, 282, 2, abilitydesc, DarkBase, DarkShadow)
    drawMarkings(overlay, 15, 291, 72, 20, pokemon.markings)
    if pokemon.hp > 0
      hpcolors = [
        Color.new(24, 192, 32), Color.new(0, 144, 0), # Green
        Color.new(248, 184, 0), Color.new(184, 112, 0),   # Orange
        Color.new(240, 80, 32), Color.new(168, 48, 56)    # Red
      ]
      hpzone = 0
      hpzone = 1 if pokemon.hp <= (@pokemon.totalhp / 2.0).floor
      hpzone = 2 if pokemon.hp <= (@pokemon.totalhp / 4.0).floor
      overlay.fill_rect(360, 110, pokemon.hp * 96 / pokemon.totalhp, 2, hpcolors[hpzone * 2 + 1])
      overlay.fill_rect(360, 112, pokemon.hp * 96 / pokemon.totalhp, 4, hpcolors[hpzone * 2])
    end
  end

  def drawPageFour(pokemon)
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    @sprites["background"].setBitmap("Graphics/Pictures/Summary/summary4")
    imagepos = []
    if pbPokerus(pokemon) == 1 || pokemon.hp == 0 || !@pokemon.status.nil?
      status = :POKERUS if pbPokerus(pokemon) == 1
      status = @pokemon.status if !@pokemon.status.nil?
      status = :FAINTED if pokemon.hp == 0
      imagepos.push([sprintf("Graphics/Pictures/Party/status%s", status), 120, 100, 0, 0, 44, 16])
    end
    if pokemon.isShiny?
      imagepos.push([sprintf("Graphics/Pictures/shiny"), 2, 134, 0, 0, -1, -1])
    end
    if pbPokerus(pokemon) == 2
      imagepos.push([sprintf("Graphics/Pictures/Summary/statusPKRS"), 176, 100, 0, 0, -1, -1])
    end
    ballused = @pokemon.ballused ? @pokemon.ballused : :POKEBALL
    ballimage = sprintf("Graphics/Pictures/Summary/summaryball" + @pokemon.ballused.to_s)
    imagepos.push([ballimage, 14, 60, 0, 0, -1, -1])
    pbDrawImagePositions(overlay, imagepos)
    statshadows = []
    for i in 0...6; statshadows[i] = LightShadow; end
    if !(pokemon.isShadow? rescue false) || pokemon.heartStage <= 3
      natup = $cache.natures[pokemon.nature].incStat
      natdn = $cache.natures[pokemon.nature].decStat
      statshadows[natup] = Color.new(136, 96, 72) if natup != natdn
      statshadows[natdn] = Color.new(64, 120, 152) if natup != natdn
    end
    pbSetSystemFont(overlay)
    if pokemon.ability.is_a?(PokeAbility)
      abil = $cache.abil[pokemon.ability.ability]
      abilityname = abil.nil? ? (pokemon.ability.ability.nil? ? NoAbilName : pokemon.ability.ability.to_s) : abil.name.nil? ? MissingAbilName : getAbilityName(pokemon.ability.ability, true)
      abilitydesc = abil.nil? ? (@pokemon.ability.ability.nil? ? NoAbilDesc : NotRealAbil) : abil.desc.nil? ? MissingAbilDesc : abil.desc
    else
        abil = $cache.abil[pokemon.ability]
        abilityname = abil.nil? ? (pokemon.ability.nil? ? NoAbilName : pokemon.ability.to_s) : abil.name.nil? ? MissingAbilName : getAbilityName(pokemon.ability, true)
        abilitydesc = abil.nil? ? (@pokemon.ability.nil? ? NoAbilDesc : NotRealAbil) : abil.desc.nil? ? MissingAbilDesc : abil.desc
    end
    if pokemon.PULSE3==true
      abilityname="Pulse-3"
      # abilitydesc="It has all of its abilities at once."
      abilitydesc=""
      abilarray = pokemon.getAbilityList
      abilarray.each do |pulse3_ability|
        pulse_abil = $cache.abil[pulse3_ability]
        pulse_abilname = pulse_abil.nil? ? (pulse3_ability.nil? ? NoAbilName : pulse3_ability.to_s) : pulse_abil.name.nil? ? MissingAbilName : getAbilityName(pulse3_ability)
        abilitydesc+=pulse_abilname
        abilitydesc+=", "
      end
      abilitydesc = abilitydesc[0..-3]
    end
    itemname = pokemon.item.nil? ? _INTL("None") : getItemName(pokemon.item)
    pokename = @pokemon.name
    if @pokemon.name.split().last == "?" || @pokemon.name.split().last == "!"
      pokename = @pokemon.name[0..-2]
    end
    # lawds combined EVs
    if $game_variables[:DifficultyModes]==2
    textpos = [
      [_INTL("EVs"), 26, 16, 0, LightBase, LightShadow],
      [pokename, 46, 62, 0, LightBase, LightShadow],
      [_INTL("{1}", pokemon.level), 46, 92, 0, DarkBase, DarkShadow],
      [_INTL("Item"), 16, 320, 0, LightBase, LightShadow],
      [itemname, 16, 352, 0, DarkBase, DarkShadow],
      [_INTL("Stat"), 292, 76, 2, LightBase, LightShadow],
      [_INTL("EV"), 456, 76, 1, DarkBase, DarkShadow],
      [_INTL("HP"), 292, 120, 2, LightBase, LightShadow],
      [_ISPRINTF("{1:3d}", pokemon.ev[0]), 456, 120, 1, DarkBase, DarkShadow],
      [_INTL("Offense"), 248, 152, 0, LightBase, LightShadow],
      [_ISPRINTF("{1:3d}", pokemon.ev[1]), 456, 152, 1, DarkBase, DarkShadow],
      [_INTL("Defense"), 248, 184, 0, LightBase, LightShadow],
      [_ISPRINTF("{1:3d}", pokemon.ev[2]), 456, 184, 1, DarkBase, DarkShadow],
      [_INTL("Sp. Def"), 248, 216, 0, LightBase, LightShadow],
      [_ISPRINTF("{1:3d}", pokemon.ev[4]), 456, 216, 1, DarkBase, DarkShadow],
      [_INTL("Speed"), 248, 248, 0, LightBase, LightShadow],
      [_ISPRINTF("{1:3d}", pokemon.ev[5]), 456, 248, 1, DarkBase, DarkShadow],
      [_INTL("Ability"), 224, 284, 0, LightBase, LightShadow],
      [abilityname, 362, 284, 0, DarkBase, DarkShadow],
    ]
    else
    textpos = [
      [_INTL("EV & IV"), 26, 16, 0, LightBase, LightShadow],
      [pokename, 46, 62, 0, LightBase, LightShadow],
      [_INTL("{1}", pokemon.level), 46, 92, 0, DarkBase, DarkShadow],
      [_INTL("Item"), 16, 320, 0, LightBase, LightShadow],
      [itemname, 16, 352, 0, DarkBase, DarkShadow],
      [_INTL("HP"), 292, 76, 2, LightBase, LightShadow],
      [_ISPRINTF("{1:3d}/{2:3d}", pokemon.ev[0], pokemon.iv[0]), 462, 76, 1, DarkBase, DarkShadow],
      [_INTL("Attack"), 248, 120, 0, LightBase, statshadows[PBStats::ATTACK]],
      [_ISPRINTF("{1:3d}/{2:3d}", pokemon.ev[1], pokemon.iv[1]), 456, 120, 1, DarkBase, DarkShadow],
      [_INTL("Defense"), 248, 152, 0, LightBase, statshadows[PBStats::DEFENSE]],
      [_ISPRINTF("{1:3d}/{2:3d}", pokemon.ev[2], pokemon.iv[2]), 456, 152, 1, DarkBase, DarkShadow],
      [_INTL("Sp. Atk"), 248, 184, 0, LightBase, statshadows[PBStats::SPATK]],
      [_ISPRINTF("{1:3d}/{2:3d}", pokemon.ev[3], pokemon.iv[3]), 456, 184, 1, DarkBase, DarkShadow],
      [_INTL("Sp. Def"), 248, 216, 0, LightBase, statshadows[PBStats::SPDEF]],
      [_ISPRINTF("{1:3d}/{2:3d}", pokemon.ev[4], pokemon.iv[4]), 456, 216, 1, DarkBase, DarkShadow],
      [_INTL("Speed"), 248, 248, 0, LightBase, statshadows[PBStats::SPEED]],
      [_ISPRINTF("{1:3d}/{2:3d}", pokemon.ev[5], pokemon.iv[5]), 456, 248, 1, DarkBase, DarkShadow],
      [_INTL("Ability"), 224, 284, 0, LightBase, LightShadow],
      [abilityname, 362, 284, 0, DarkBase, DarkShadow],
    ]
    end
    if pokemon.isMale?
      textpos.push([_INTL("♂"), 178, 62, 0, Color.new(24, 112, 216), Color.new(136, 168, 208)])
    elsif pokemon.isFemale?
      textpos.push([_INTL("♀"), 178, 62, 0, ShinyBase, ShinyShadow])
    end
    pbDrawTextPositions(overlay, textpos)
    drawTextEx(overlay, 224, 316, 282, 2, abilitydesc, DarkBase, DarkShadow)
    drawMarkings(overlay, 15, 291, 72, 20, pokemon.markings)
    if pokemon.hp > 0
      hpcolors = [
        Color.new(24, 192, 32), Color.new(0, 144, 0), # Green
        Color.new(248, 184, 0), Color.new(184, 112, 0),   # Orange
        Color.new(240, 80, 32), Color.new(168, 48, 56)    # Red
      ]
      hpzone = 0
      hpzone = 1 if pokemon.hp <= (@pokemon.totalhp / 2.0).floor
      hpzone = 2 if pokemon.hp <= (@pokemon.totalhp / 4.0).floor
      overlay.fill_rect(360, 110, pokemon.hp * 96 / pokemon.totalhp, 2, hpcolors[hpzone * 2 + 1])
      overlay.fill_rect(360, 112, pokemon.hp * 96 / pokemon.totalhp, 4, hpcolors[hpzone * 2])
    end
  end

  def drawPageFive(pokemon)
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    @sprites["background"].setBitmap("Graphics/Pictures/Summary/summary5")
    @sprites["pokemon"].visible = true
    @sprites["pokeicon"].visible = false
    imagepos = []
    if pbPokerus(pokemon) == 1 || pokemon.hp == 0 || !@pokemon.status.nil?
      status = :POKERUS if pbPokerus(pokemon) == 1
      status = @pokemon.status if !@pokemon.status.nil?
      status = :FAINTED if pokemon.hp == 0
      imagepos.push([sprintf("Graphics/Pictures/Party/status%s", status), 120, 100, 0, 0, 44, 16])
    end
    if pokemon.isShiny?
      imagepos.push([sprintf("Graphics/Pictures/shiny"), 2, 134, 0, 0, -1, -1])
    end
    if pbPokerus(pokemon) == 2
      imagepos.push([sprintf("Graphics/Pictures/Summary/statusPKRS"), 176, 100, 0, 0, -1, -1])
    end
    ballused = @pokemon.ballused ? @pokemon.ballused : :POKEBALL
    ballimage = sprintf("Graphics/Pictures/Summary/summaryball" + @pokemon.ballused.to_s)
    imagepos.push([ballimage, 14, 60, 0, 0, -1, -1])
    pbDrawImagePositions(overlay, imagepos)
    pbSetSystemFont(overlay)
    itemname = pokemon.hasAnItem? ? getItemName(pokemon.item) : _INTL("None")
    pokename = @pokemon.name
    textpos = [
      [_INTL("MOVES"), 26, 16, 0, LightBase, LightShadow],
      [pokename, 46, 62, 0, LightBase, LightShadow],
      [pokemon.level.to_s, 46, 92, 0, DarkBase, DarkShadow],
      [_INTL("Item"), 16, 320, 0, LightBase, LightShadow],
      [itemname, 16, 352, 0, DarkBase, DarkShadow],
    ]
    if pokemon.isMale?
      textpos.push([_INTL("♂"), 178, 62, 0, Color.new(24, 112, 216), Color.new(136, 168, 208)])
    elsif pokemon.isFemale?
      textpos.push([_INTL("♀"), 178, 62, 0, ShinyBase, ShinyShadow])
    end
    pbDrawTextPositions(overlay, textpos)
    imagepos = []
    yPos = 98
    for i in 0...pokemon.moves.length
      if pokemon.moves[i].move != nil
        # added Hidden Power type check
        if pokemon.moves[i].move == :HIDDENPOWER
          pbHiddenPower(pokemon) if !pokemon.hptype
          imagepos.push([sprintf("Graphics/Icons/type%s", pokemon.hptype), 248, yPos + 2, 0, 0, 64, 28])
        else
          imagepos.push([sprintf("Graphics/Icons/type%s", pokemon.moves[i].type), 248, yPos + 2, 0, 0, 64, 28])
        end
        textpos.push([getMoveShortName(pokemon.moves[i].move), 316, yPos, 0, DarkBase, DarkShadow])
        if pokemon.moves[i].totalpp > 0
          textpos.push([_ISPRINTF("PP"), 342, yPos + 32, 0, DarkBase, DarkShadow])
          textpos.push([sprintf("%d/%d", pokemon.moves[i].pp, pokemon.moves[i].totalpp), 460, yPos + 32, 1, DarkBase, DarkShadow])
        end
      else
        textpos.push(["-", 316, yPos, 0, DarkBase, DarkShadow])
        textpos.push(["--", 442, yPos + 32, 1, DarkBase, DarkShadow])
      end
      yPos += 64
    end
    imagepos.push(["Graphics/Pictures/Summary/summary5zmovebtn", 324, 60, 0, 0, -1, -1]) if pokemon.zmoves != nil && pokemon.zmoves.any? {|x| x != nil}
    pbDrawTextPositions(overlay, textpos)
    pbDrawImagePositions(overlay, imagepos)
    drawMarkings(overlay, 15, 291, 72, 20, pokemon.markings)
  end

  def drawZMovePage(pokemon)
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    @sprites["background"].setBitmap("Graphics/Pictures/Summary/summary5")
    @sprites["pokemon"].visible = true
    @sprites["pokeicon"].visible = false
    imagepos = []
    if pbPokerus(pokemon) == 1 || pokemon.hp == 0 || !@pokemon.status.nil?
      status = :POKERUS if pbPokerus(pokemon) == 1
      status = @pokemon.status if !@pokemon.status.nil?
      status = :FAINTED if pokemon.hp == 0
      imagepos.push([sprintf("Graphics/Pictures/Party/status%s", status), 120, 100, 0, 0, 44, 16])
    end
    if pokemon.isShiny?
      imagepos.push([sprintf("Graphics/Pictures/shiny"), 2, 134, 0, 0, -1, -1])
    end
    if pbPokerus(pokemon) == 2
      imagepos.push([sprintf("Graphics/Pictures/Summary/statusPKRS"), 176, 100, 0, 0, -1, -1])
    end
    ballused = @pokemon.ballused ? @pokemon.ballused : :POKEBALL
    ballimage = sprintf("Graphics/Pictures/Summary/summaryball" + @pokemon.ballused.to_s)
    imagepos.push([ballimage, 14, 60, 0, 0, -1, -1])
    pbDrawImagePositions(overlay, imagepos)
    pbSetSystemFont(overlay)
    itemname = pokemon.hasAnItem? ? getItemName(pokemon.item) : _INTL("None")
    pokename = @pokemon.name
    textpos = [
      [_INTL("MOVES"), 26, 16, 0, LightBase, LightShadow],
      [pokename, 46, 62, 0, LightBase, LightShadow],
      [pokemon.level.to_s, 46, 92, 0, DarkBase, DarkShadow],
      [_INTL("Item"), 16, 320, 0, LightBase, LightShadow],
      [itemname, 16, 352, 0, DarkBase, DarkShadow],
    ]
    if pokemon.isMale?
      textpos.push([_INTL("♂"), 178, 62, 0, Color.new(24, 112, 216), Color.new(136, 168, 208)])
    elsif pokemon.isFemale?
      textpos.push([_INTL("♀"), 178, 62, 0, ShinyBase, ShinyShadow])
    end
    pbDrawTextPositions(overlay, textpos)
    imagepos = []
    yPos = 98
    for i in 0...pokemon.moves.length
      if pokemon.zmoves[i] != nil && pokemon.zmoves[i].move != nil
        imagepos.push([sprintf("Graphics/Icons/type%s", pokemon.zmoves[i].type), 248, yPos + 2, 0, 0, 64, 28])
        name = getMoveName(pokemon.zmoves[i].move)
        name = "Menace Moonraze Maelstrom" if pokemon.zmoves[i].move == :MENACINGMOONRAZEMAELSTROM
        name = "Z-" + name if $cache.moves[pokemon.zmoves[i].move].category == :status && pokemon.zmoves[i].move != :EXTREMEEVOBOOST
        drawTextEx(overlay, 316, yPos - 3, 174, 2, name, DarkBase, DarkShadow)
      elsif pokemon.moves[i].move != nil
        # added Hidden Power type check
        if pokemon.moves[i].move == :HIDDENPOWER
          pbHiddenPower(pokemon) if !pokemon.hptype
          imagepos.push([sprintf("Graphics/Icons/type%s", pokemon.hptype), 248, yPos + 2, 0, 0, 64, 28])
        else
          imagepos.push([sprintf("Graphics/Icons/type%s", pokemon.moves[i].type), 248, yPos + 2, 0, 0, 64, 28])
        end
        textpos.push([getMoveShortName(pokemon.moves[i].move), 316, yPos, 0, DarkBase, DarkShadow])
        if pokemon.moves[i].totalpp > 0
          textpos.push([_ISPRINTF("PP"), 342, yPos + 32, 0, DarkBase, DarkShadow])
          textpos.push([sprintf("%d/%d", pokemon.moves[i].pp, pokemon.moves[i].totalpp), 460, yPos + 32, 1, DarkBase, DarkShadow])
        end
      else
        textpos.push(["-", 316, yPos, 0, DarkBase, DarkShadow])
        textpos.push(["--", 442, yPos + 32, 1, DarkBase, DarkShadow])
      end
      yPos += 64
    end
    imagepos.push(["Graphics/Pictures/Summary/summary5movebtn", 324, 60, 0, 0, -1, -1])
    pbDrawTextPositions(overlay, textpos)
    pbDrawImagePositions(overlay, imagepos)
    drawMarkings(overlay, 15, 291, 72, 20, pokemon.markings)
  end

  def drawMoveSelection(pokemon, moveToLearn)
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    @sprites["background"].setBitmap("Graphics/Pictures/Summary/summary5details")
    if moveToLearn != 0
      @sprites["background"].setBitmap("Graphics/Pictures/Summary/summary5learning")
    end
    pbSetSystemFont(overlay)
    textpos = [
      [_INTL("MOVES"), 26, 16, 0, LightBase, LightShadow],
      [_INTL("CATEGORY"), 20, 122, 0, LightBase, LightShadow],
      [_INTL("POWER"), 20, 154, 0, LightBase, LightShadow],
      [_INTL("ACCURACY"), 20, 186, 0, LightBase, LightShadow]
    ]
    type1rect = Rect.new(0, 0, 64, 28)
    type2rect = Rect.new(0, 0, 64, 28)
    if pokemon.type2.nil? || pokemon.type1 == pokemon.type2
      type1image = AnimatedBitmap.new(sprintf("Graphics/Icons/type%s", pokemon.type1))
      overlay.blt(130, 78, type1image.bitmap, type1rect)
    else
      type1image = AnimatedBitmap.new(sprintf("Graphics/Icons/type%s", pokemon.type1))
      type2image = AnimatedBitmap.new(sprintf("Graphics/Icons/type%s", pokemon.type2))
      overlay.blt(96, 78, type1image.bitmap, type1rect)
      overlay.blt(166, 78, type2image.bitmap, type2rect)
    end
    imagepos = []
    yPos = 98
    yPos -= 76 if moveToLearn != 0
    for i in 0...5
      moveobject = nil
      if i == 4
        moveobject = PBMove.new(moveToLearn) if moveToLearn != 0
        yPos += 20
      else
        moveobject = (@zmovepage && !pokemon.zmoves[i].nil?) ? pokemon.zmoves[i] : pokemon.moves[i]
      end
      if moveobject
        if @zmovepage && !pokemon.zmoves[i].nil? && moveobject.move != nil
          imagepos.push([sprintf("Graphics/Icons/type%s", moveobject.type), 248, yPos + 2, 0, 0, 64, 28])
          name = getMoveName(moveobject.move)
          name = "Menace Moonraze Maelstrom" if moveobject.move == :MENACINGMOONRAZEMAELSTROM
          name = "Z-" + name if $cache.moves[moveobject.move].category == :status && moveobject.move != :EXTREMEEVOBOOST
          drawTextEx(overlay, 316, yPos - 3, 174, 2, name, DarkBase, DarkShadow)
        elsif moveobject.move != nil
          # added Hidden Power type check
          if moveobject.move == :HIDDENPOWER
            pbHiddenPower(pokemon) if !pokemon.hptype
            imagepos.push([sprintf("Graphics/Icons/type%s", pokemon.hptype), 248, yPos + 2, 0, 0, 64, 28])
          else
            imagepos.push([sprintf("Graphics/Icons/type%s", moveobject.type), 248, yPos + 2, 0, 0, 64, 28])
          end
          textpos.push([getMoveShortName(moveobject.move), 316, yPos, 0, DarkBase, DarkShadow])
          if moveobject.totalpp > 0
            textpos.push([_ISPRINTF("PP"), 342, yPos + 32, 0, DarkBase, DarkShadow])
            textpos.push([sprintf("%d/%d", moveobject.pp, moveobject.totalpp), 460, yPos + 32, 1, DarkBase, DarkShadow])
          end
        else
          textpos.push(["-", 316, yPos, 0, DarkBase, DarkShadow])
          textpos.push(["--", 442, yPos + 32, 1, DarkBase, DarkShadow])
        end
      end
      yPos += 64
    end
    pbDrawTextPositions(overlay, textpos)
    pbDrawImagePositions(overlay, imagepos)
  end

end