def pbBattleAnimation(bgm=nil,trainerid=-1,trainername="",switch_sprites=false,vsoutfit=0)
  handled=false
  playingBGS=nil
  playingBGM=nil
  if $game_system && $game_system.is_a?(Game_System)
    playingBGS=$game_system.getPlayingBGS
    playingBGM=$game_system.getPlayingBGM
    playingBGMposition = Audio.bgm_pos if playingBGM
    $game_system.bgm_pause
    $game_system.bgs_pause
  end
  pbMEFade(0.25)
  pbWait(10)
  pbMEStop
  if bgm
    pbBGMPlay(bgm)
  else
    pbBGMPlay(pbGetWildBattleBGM(0))
  end
  viewport=Viewport.new(0,0,Graphics.width,Graphics.height)
  viewport.z=99999
  # Fade to gray a few times.
  if $Settings.photosensitive != 1
    viewport.color=Color.new(17*8,17*8,17*8)
    3.times do
      viewport.color.alpha=0
      6.times do
        viewport.color.alpha+=30
        Graphics.update
        Input.update
        pbUpdateSceneMap
      end
      6.times do
        viewport.color.alpha-=30
        Graphics.update
        Input.update
        pbUpdateSceneMap
      end
    end
  end
  ################################################################################
  # VS. animation, by Luka S.J.
  # Tweaked by Maruno.
  # Tweaked by Perry to allow for doubles!
  ###############################################################################
  if vsoutfit!=0 && vsoutfit!=[0,0] 
    if trainerid.is_a?(Array)
      tbargraphic=sprintf("Graphics/Transitions/vsBar%s_%d",$cache.trainertypes[trainerid[0]].checkFlag?(:ID),vsoutfit[0])
      tbargraphic2=sprintf("Graphics/Transitions/vsBar%s_%d",$cache.trainertypes[trainerid[1]].checkFlag?(:ID),vsoutfit[1])
      tbargraphic=sprintf("Graphics/Transitions/vsBar%s",$cache.trainertypes[trainerid[0]].checkFlag?(:ID)) if !pbResolveBitmap(tbargraphic)
      tbargraphic2=sprintf("Graphics/Transitions/vsBar%s",$cache.trainertypes[trainerid[1]].checkFlag?(:ID)) if !pbResolveBitmap(tbargraphic2)
      tgraphic=sprintf("Graphics/Transitions/vsTrainer%s_%d",$cache.trainertypes[trainerid[0]].checkFlag?(:ID),vsoutfit[0])
      tgraphic2=sprintf("Graphics/Transitions/vsTrainer%s_%d", $cache.trainertypes[trainerid[1]].checkFlag?(:ID),vsoutfit[1])
      tgraphic=sprintf("Graphics/Transitions/vsTrainer%s",$cache.trainertypes[trainerid[0]].checkFlag?(:ID)) if !pbResolveBitmap(tgraphic)
      tgraphic2=sprintf("Graphics/Transitions/vsTrainer%s", $cache.trainertypes[trainerid[1]].checkFlag?(:ID)) if !pbResolveBitmap(tgraphic2)
    elsif !$cache.trainertypes[trainerid].nil?
      tbargraphic=sprintf("Graphics/Transitions/vsBar%s_%d", $cache.trainertypes[trainerid].checkFlag?(:ID),vsoutfit)
      tgraphic=sprintf("Graphics/Transitions/vsTrainer%s_%d", $cache.trainertypes[trainerid].checkFlag?(:ID),vsoutfit)
      tbargraphic=sprintf("Graphics/Transitions/vsBar%s", $cache.trainertypes[trainerid].checkFlag?(:ID)) if !pbResolveBitmap(tbargraphic)
      tgraphic=sprintf("Graphics/Transitions/vsTrainer%s", $cache.trainertypes[trainerid].checkFlag?(:ID)) if !pbResolveBitmap(tgraphic)
    end
  else
    if trainerid.is_a?(Array)
      tbargraphic=sprintf("Graphics/Transitions/vsBar%s",$cache.trainertypes[trainerid[0]].checkFlag?(:ID))
      tbargraphic2=sprintf("Graphics/Transitions/vsBar%s",$cache.trainertypes[trainerid[1]].checkFlag?(:ID))
      tgraphic=sprintf("Graphics/Transitions/vsTrainer%s",$cache.trainertypes[trainerid[0]].checkFlag?(:ID))
      tgraphic2=sprintf("Graphics/Transitions/vsTrainer%s", $cache.trainertypes[trainerid[1]].checkFlag?(:ID))
    elsif !$cache.trainertypes[trainerid].nil?
      tbargraphic=sprintf("Graphics/Transitions/vsBar%s", $cache.trainertypes[trainerid].checkFlag?(:ID))
      tgraphic=sprintf("Graphics/Transitions/vsTrainer%s", $cache.trainertypes[trainerid].checkFlag?(:ID))
    end
  end
  if $PokemonGlobal.partner
    partnergraphic = sprintf("Graphics/Transitions/vsTrainer%s",$cache.trainertypes[$PokemonGlobal.partner[0]].checkFlag?(:ID))
  end
  if ((trainerid.is_a?(Array) && ((pbResolveBitmap(tbargraphic) && pbResolveBitmap(tgraphic)) ||
    (pbResolveBitmap(tbargraphic2) && pbResolveBitmap(tgraphic2)))) || 
    (pbResolveBitmap(tbargraphic) && pbResolveBitmap(tgraphic))) && !$game_switches[:VSGraphicOff]
    outfit=$Trainer ? $Trainer.outfit : 0
    # Set up
    viewplayer=Viewport.new(0,Graphics.height/3,Graphics.width/2,128)
    viewplayer.z=viewport.z
    viewopp=Viewport.new(Graphics.width/2,Graphics.height/3,Graphics.width/2,128)
    viewopp.z=viewport.z
    viewvs=Viewport.new(0,0,Graphics.width,Graphics.height)
    viewvs.z=viewport.z
    xoffset=(Graphics.width/2)/10
    xoffset=xoffset.round
    xoffset=xoffset*10

    fade=Sprite.new(viewport)
    fade.bitmap  = RPG::Cache.transition("Graphics/Transitions/vsFlash")
    fade.tone=Tone.new(-255,-255,-255)
    fade.opacity=100
    overlay=Sprite.new(viewport)
    overlay.bitmap=Bitmap.new(Graphics.width,Graphics.height)
    pbSetSystemFont(overlay.bitmap)
    bar1=Sprite.new(viewplayer)
    pbargraphic=sprintf("Graphics/Transitions/vsBar%d_%d",$cache.trainertypes[$Trainer.trainertype].checkFlag?(:ID),outfit)
    pbargraphic=sprintf("Graphics/Transitions/vsBar%d",$cache.trainertypes[$Trainer.trainertype].checkFlag?(:ID)) if !pbResolveBitmap(pbargraphic)
    bar1.bitmap = RPG::Cache.transition(pbargraphic)
    bar1.x=-xoffset
    bar2=Sprite.new(viewopp)
    if trainerid.is_a?(Array) && !pbResolveBitmap(tgraphic)
      bar2.bitmap = RPG::Cache.transition(tbargraphic2)
    else
      bar2.bitmap = RPG::Cache.transition(tbargraphic)
    end
    bar2.x=xoffset

    vs=Sprite.new(viewvs)
    vs.bitmap  = RPG::Cache.transition("Graphics/Transitions/vs")
    vs.ox=vs.bitmap.width/2
    vs.oy=vs.bitmap.height/2
    vs.x=Graphics.width/2
    vs.y=Graphics.height/1.5
    vs.visible=false
    flash=Sprite.new(viewvs)
    flash.bitmap  = RPG::Cache.transition("Graphics/Transitions/vsFlash")
    flash.opacity=0

    # Animation
    10.times do
      bar1.x+=xoffset/10
      bar2.x-=xoffset/10
      pbWait(1)
    end
    pbSEPlay("PRSFX- Counter2")
    pbSEPlay("PRSFX- Flash")
    flash.opacity=255 if $Settings.photosensitive != 1
    bar1.dispose
    bar2.dispose

    bar1=AnimatedPlane.new(viewplayer)
    bar1.bitmap = RPG::Cache.transition(pbargraphic)
    player=Sprite.new(viewplayer)
    pgraphic=sprintf("Graphics/Transitions/vsTrainer%d_%d",$cache.trainertypes[$Trainer.trainertype].checkFlag?(:ID),outfit)
    pgraphic=sprintf("Graphics/Transitions/vsTrainer%d",$cache.trainertypes[$Trainer.trainertype].checkFlag?(:ID)) if !pbResolveBitmap(pgraphic)
    player.bitmap=RPG::Cache.transition(pgraphic)
    player.x=-xoffset
    partner = nil
    if $PokemonGlobal.partner && pbResolveBitmap(partnergraphic)
      partner = Sprite.new(viewplayer) if pbResolveBitmap(partnergraphic)
      partner.bitmap=RPG::Cache.transition(partnergraphic)
      partner.x=-xoffset + partner.width/30
      player.x-= partner.width/4.5
      partner.mirror = true 
	  player.z = viewplayer.z + 20
	  partner.z = viewplayer.z + 10
    end
    bar2=AnimatedPlane.new(viewopp)
    if trainerid.is_a?(Array) && !pbResolveBitmap(tgraphic)
      bar2.bitmap = RPG::Cache.transition(tbargraphic2)
    else
      bar2.bitmap = RPG::Cache.transition(tbargraphic)
    end
    trainer=BitmapSprite.new(Graphics.width, Graphics.height, viewopp)
    if trainerid.is_a?(Array) && pbResolveBitmap(tgraphic) && pbResolveBitmap(tgraphic2) # both trainers have sprite
      trainer1bitmap = RPG::Cache.transition(tgraphic)
      trainer2bitmap = RPG::Cache.transition(tgraphic2)
      if !switch_sprites
        trainer.bitmap.blt(-trainer1bitmap.width/6,0,trainer1bitmap,Rect.new(0,0,trainer1bitmap.width,trainer1bitmap.height))
        trainer.bitmap.blt(trainer2bitmap.width/4,0,trainer2bitmap,Rect.new(0,0,trainer2bitmap.width,trainer2bitmap.height))
      else
        trainer.bitmap.blt(-trainer2bitmap.width/4,0,trainer2bitmap,Rect.new(0,0,trainer2bitmap.width,trainer2bitmap.height))
        trainer.bitmap.blt(trainer1bitmap.width/4,0,trainer1bitmap,Rect.new(0,0,trainer1bitmap.width,trainer1bitmap.height))
      end
    elsif trainerid.is_a?(Array) && pbResolveBitmap(tgraphic2) # only second one has sprite
      trainer2bitmap = RPG::Cache.transition(tgraphic2)
      trainer.bitmap.blt(0,0,trainer2bitmap,Rect.new(0,0,trainer2bitmap.width,trainer2bitmap.height))
    else
      trainer1bitmap = RPG::Cache.transition(tgraphic)
      trainer.bitmap.blt(0,0,trainer1bitmap,Rect.new(0,0,trainer1bitmap.width,trainer1bitmap.height))
    end
    trainer.x=xoffset
    trainer.tone=Tone.new(-255,-255,-255)
    trainer.visible=false
    partner.visible=false if partner
    
    25.times do
      flash.opacity-=51 if flash.opacity>0
      bar1.ox-=16
      bar2.ox+=16
      pbWait(1)
    end
    trainer.visible=true
    partner.visible=true if partner
    11.times do
      bar1.ox-=16
      bar2.ox+=16
      player.x+=xoffset/10
      partner.x+=xoffset/10 if partner
      trainer.x-=xoffset/10
      pbWait(1)
    end
    2.times do
      bar1.ox-=16
      bar2.ox+=16
      player.x-=xoffset/20
      partner.x+=xoffset/20 if partner
      trainer.x+=xoffset/20
      pbWait(1)
    end
    10.times do
      bar1.ox-=16
      bar2.ox+=16
      pbWait(1)
    end
    val=2
    flash.opacity=255 if $Settings.photosensitive != 1
    vs.visible=true
    trainer.tone=Tone.new(0,0,0)
    #Opponents name
    if trainerid.is_a?(Array) && pbResolveBitmap(tgraphic) && pbResolveBitmap(tgraphic2)
      trainername = _INTL("{1} & {2}",trainername[0],trainername[1])
    elsif trainerid.is_a?(Array) && pbResolveBitmap(tgraphic)
      trainername = _INTL("{1}",trainername[0])
    elsif trainerid.is_a?(Array) && pbResolveBitmap(tgraphic2)
      trainername =  _INTL("{1}",trainername[1])
    end
    trainername2 = ""
    if trainername.length > 16
      splits = trainername.split(/ /,trainername[0,16].split(/ /).length)
      trainername2 = splits.delete_at(-1)
      trainername = splits.join(" ")
    end

    #player name
    playername = $Trainer.name
    if $PokemonGlobal.partner && pbResolveBitmap(partnergraphic)
      playername =  _INTL("{1} & {2}",$Trainer.name,$PokemonGlobal.partner[1])
    end
    playername2 = ""
    if playername.length > 16
      splits = playername.split(/ /,playername[0,16].split(/ /).length)
      playername2 = splits.delete_at(-1)
      playername = splits.join(" ")
    end
    #placing names
    textpos=[
      [_INTL("{1}",playername) ,   Graphics.width/4  - 16,(Graphics.height/1.5)+10,2, Color.new(248,248,248),Color.new(72,72,72)],
      [_INTL("{1}",trainername),(3*Graphics.width/4) + 16,(Graphics.height/1.5)+10,2, Color.new(248,248,248),Color.new(72,72,72)]
    ]
    textpos.push( [_INTL("{1}",trainername2),(3*Graphics.width/4) + 16,(Graphics.height/1.5)+42,2, Color.new(248,248,248),Color.new(72,72,72)]) if trainername2 != ""
    textpos.push( [_INTL("{1}",playername2),    Graphics.width/4  - 16,(Graphics.height/1.5)+42,2, Color.new(248,248,248),Color.new(72,72,72)]) if playername2 != ""
    pbDrawTextPositions(overlay.bitmap,textpos)

    pbSEPlay("Sword2")
    70.times do
      bar1.ox-=16
      bar2.ox+=16
      flash.opacity-=25.5 if flash.opacity>0
      vs.x+=val
      vs.y-=val
      val=2 if vs.x<=(Graphics.width/2)-2
      val=-2 if vs.x>=(Graphics.width/2)+2
      pbWait(1)
    end
    30.times do
      bar1.ox-=16
      bar2.ox+=16
      vs.zoom_x+=0.2
      vs.zoom_y+=0.2
      pbWait(1)
    end
    flash.tone=Tone.new(-255,-255,-255)
    10.times do
      bar1.ox-=16
      bar2.ox+=16
      flash.opacity+=25.5
      pbWait(1)
    end
    # End
    player.dispose
    partner.dispose if partner
    trainer.dispose
    flash.dispose
    vs.dispose
    bar1.dispose
    bar2.dispose
    overlay.dispose
    fade.dispose
    viewvs.dispose
    viewopp.dispose
    viewplayer.dispose
    viewport.color=Color.new(0,0,0,255)
    handled=true
  end
  # End of VS. sequence script
  if !handled
    if Sprite.method_defined?(:wave_amp) && rand(15)==0
      viewport.color=Color.new(0,0,0,255)
      sprite = Sprite.new
      bitmap=Graphics.snap_to_bitmap
      bm=bitmap.clone
      sprite.z=99999
      sprite.bitmap = bm
      sprite.wave_speed=500
      for i in 0..25
        sprite.opacity-=10
        sprite.wave_amp+=60
        sprite.update
        sprite.wave_speed+=30
        2.times do
          Graphics.update
        end
      end
      bitmap.dispose
      bm.dispose
      sprite.dispose
    elsif Bitmap.method_defined?(:radial_blur) && rand(15)==0
      viewport.color=Color.new(0,0,0,255)
      sprite = Sprite.new
      bitmap=Graphics.snap_to_bitmap
      bm=bitmap.clone
      sprite.z=99999
      sprite.bitmap = bm
      for i in 0..15
        bm.radial_blur(i,2)
        sprite.opacity-=15
        2.times do
          Graphics.update
        end
      end
      bitmap.dispose
      bm.dispose
      sprite.dispose
    else
      transitions=["021-Normal01","022-Normal02",
         "Battle","battle1","battle2","battle3","battle4",
         "computertr","computertrclose",
         "hexatr","hexatrc","hexatzr",
      ]

      rnd=rand(transitions.length)
      Graphics.freeze
      viewport.color=Color.new(0,0,0,255)
      Graphics.transition(40,sprintf("Graphics/Transitions/%s",transitions[rnd]))
    end
    5.times do
      Graphics.update
      Input.update
      pbUpdateSceneMap
    end
  end
  pbPushFade
  yield if block_given?
  pbPopFade
  if $game_system && $game_system.is_a?(Game_System)
    $game_system.bgm_resume(playingBGM, playingBGMposition)
    $game_system.bgs_resume(playingBGS)
  end
  $PokemonGlobal.nextBattleBGM=nil
  $PokemonGlobal.nextBattleME=nil
  $PokemonGlobal.nextBattleBack=nil
  $PokemonEncounters.clearStepCount
  for j in 0..17
    viewport.color=Color.new(0,0,0,(17-j)*15)
    Graphics.update
    Input.update
    pbUpdateSceneMap
  end
  viewport.dispose
end
